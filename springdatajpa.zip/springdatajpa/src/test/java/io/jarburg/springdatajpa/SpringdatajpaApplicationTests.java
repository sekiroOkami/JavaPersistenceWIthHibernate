package io.jarburg.springdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
